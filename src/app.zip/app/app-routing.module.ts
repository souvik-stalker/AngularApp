import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list.component';
import { EmployeeDetailComponent } from './employee-detail.component';
import { DepartmentListComponent } from './department-list.component';
import { DepartmentDetailComponent } from './department-detail.component';
import { HomeComponent } from './home.component';
import { PageNotFoundComponent } from './page-not-found.component';
const routes:Routes=[
    //{path:'',component:HomeComponent},
    //prefix,full
    
    {path:'',redirectTo:"/departments",pathMatch:'full'},
    //{path:'',component:HomeComponent},
    {path:'employees',component:EmployeeListComponent},
    {path:'departments',component:DepartmentListComponent},
    {path:'departments/:id',component:DepartmentDetailComponent},
    {path:'extra',loadChildren:'extramodule/extra.module#ExtraModule'},
    {path:'**',component:PageNotFoundComponent}
    
    ];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
       RouterModule 
  ]
})

export class AppRoutingModule{}
export const routingComponents=[EmployeeDetailComponent,DepartmentListComponent,EmployeeListComponent,DepartmentDetailComponent,HomeComponent,PageNotFoundComponent];